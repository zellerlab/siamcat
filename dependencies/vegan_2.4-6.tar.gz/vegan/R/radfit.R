`radfit` <-
    function (x, ...)
{
    UseMethod("radfit")
}
