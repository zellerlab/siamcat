`print.summary.taxondive` <-
function (x, ...) 
{
	printCoefmat(x, na.print="", ...)
	invisible(x)
}

