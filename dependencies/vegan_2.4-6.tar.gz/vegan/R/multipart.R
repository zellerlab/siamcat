multipart <-
function (...) 
{
   UseMethod("multipart")
}
