predict.fishnet=function(object,newx,s=NULL,type=c("link","response","coefficients","nonzero"),exact=FALSE,newoffset,...){
  type=match.arg(type)
nfit=NextMethod("predict")
  switch(type,
         response=exp(nfit),
         nfit
         )
}
